package me.t3sl4.textfileencoder;

import me.t3sl4.textfileencoder.Main.TFEncoder;

public class Runner {

    public static void main(String[] args) {
        TFEncoder.main(args);
    }
}
